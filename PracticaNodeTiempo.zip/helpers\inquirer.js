const inquirer = require('inquirer');
require('colors');

const preguntas = [
    {
        type: 'list',
        name: 'opcion',
        message: '¿Qué desea hacer?',
        choices: [
            { value: '1', name: `${ '1.'.green } Buscar ciudad` },
            { value: '2', name: `${ '2.'.green } Historial` },
            { value: '0', name: `${ '0.'.green } Salir` }
        ]
    }
];

const inquirerMenu = async () => {
    console.clear();
    console.log('==================================='.green);
    console.log('   Seleccione una opción: '.white);
    console.log('===================================\n'.green);

    const { opcion } = await inquirer.prompt(preguntas);
    return opcion;
};

const pausa = async () => {
    const question = [
        {
            type: 'input',
            name: 'enter',
            message: `Presione ${ 'ENTER'.green } para continuar`
        }
    ];
    console.log('\n');
    await inquirer.prompt(question);
};

const leerInput = async (mensaje) => {
    const question = [
        {
            type: 'input',
            name: 'texto',
            message: mensaje,
            validate(valor) {
                if (valor.length === 0) {
                    return 'Por favor ingrese un valor';
                }
                return true;
            }
        }
    ];

    const { texto } = await inquirer.prompt(question);
    return texto;
};

const listarLugares = async (lugares = []) => {
    const choices = lugares.map((lugar, i) => {
        const idx = `${ i + 1 }.`.green;
        return {
            value: lugar.id,
            name: `${ idx } ${ lugar.nombre }`
        };
    });

    choices.unshift({
        value: '0',
        name: '0.'.green + ' Cancelar'
    });

    const preguntas = [
        {
            type: 'list',
            name: 'id',
            message: 'Seleccione lugar:',
            choices
        }
    ];

    const { id } = await inquirer.prompt(preguntas);
    return id;
};

module.exports = {
    inquirerMenu,
    pausa,
    leerInput,
    listarLugares
};
